from sklearn import datasets
import pandas as pd
from sklearn.linear_model import LinearRegression
# TODO


#get x
# TODO 


#Total number of examples
# TODO 


print('Total number of examples')
print('MSE='                 )
print('R-squared='           )
#3:1 100
xTrain2, xTest2, yTrain2, yTest2=
lm2=LinearRegression()
lm2.fit(    ,    )
# TODO 



print('Split 3:1')
print('train MSE='            )
print('test MSE='             )
print('train R-squared='               )
print('test R-squared='                )
